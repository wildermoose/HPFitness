/** Automatically generated file. DO NOT MODIFY */
package com.wildermuth.hpfitness;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}