package com.wildermuth.hpfitness.model;

import com.wildermuth.hpfitness.control.Utils;

/**
 * @author $Author: jeff $
 * @version $Rev: 1 $
 * 
 */
public class LeaderboardEntry
{
	private int userId = 0;
	private String username = null;
	private int stepCount = 0;
	private int height = 0;
	private int distanceWalked = 0;

	

	/**
	 * @param userId
	 * @param username
	 * @param stepCount
	 * @param height
	 */
	public LeaderboardEntry(int userId, String username, int stepCount, int height)
	{
		super();
		this.userId = userId;
		this.username = username;
		this.stepCount = stepCount;
		this.height = height;
	}

	public LeaderboardEntry()
	{
		super();
	}

	public int getUserId()
	{
		return userId;
	}

	public void setUserId(int userId)
	{
		this.userId = userId;
	}

	public String getUsername()
	{
		return username;
	}

	public void setUsername(String username)
	{
		this.username = username;
	}

	public int getStepCount()
	{
		return stepCount;
	}

	public void setStepCount(int stepCount)
	{
		this.stepCount = stepCount;
	}

	public int getHeight()
	{
		return height;
	}

	public void setHeight(int height)
	{
		this.height = height;
	}
	
	public double calculateDistance()
	{
		return Utils.convertStepsToDistance(height, stepCount);
	}

}
