package com.wildermuth.hpfitness.model;

/**
 * @author $Author: jeff $
 * @version $Rev: 1 $
 *
 */
public class HPAddress
{
	private String formattedAddress = null;
	private double latitude = 0;
	private double longitude = 0;
	
	
	/**
	 * default
	 */
	public HPAddress()
	{
		super();
	}
	
	/**
	 * 
	 * @param address
	 * @param latitude
	 * @param longitude
	 */
	public HPAddress(String address, double latitude, double longitude)
	{
		super();
		this.formattedAddress = address;
		this.latitude = latitude;
		this.longitude = longitude;
	}
	public String getFormattedAddress()
	{
		return formattedAddress;
	}
	public void setFormattedAddress(String address)
	{
		this.formattedAddress = address;
	}
	public double getLatitude()
	{
		return latitude;
	}
	public void setLatitude(double latitude)
	{
		this.latitude = latitude;
	}
	public double getLongitude()
	{
		return longitude;
	}
	public void setLongitude(double longitude)
	{
		this.longitude = longitude;
	}
	
	
}
