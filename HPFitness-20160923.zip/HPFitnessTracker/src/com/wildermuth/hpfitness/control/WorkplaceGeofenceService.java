package com.wildermuth.hpfitness.control;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Timer;
import java.util.TimerTask;

import android.app.IntentService;
import android.app.Notification;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.TaskStackBuilder;
import android.content.Context;
import android.content.Intent;
import android.graphics.BitmapFactory;
import android.util.Log;

import com.google.android.gms.location.Geofence;
import com.google.android.gms.location.GeofencingEvent;
import com.wildermuth.hpfitness.R;
import com.wildermuth.hpfitness.view.HomeActivity;

/**
 * @author $Author: jeff $
 * @version $Rev: 1 $
 * 
 */
public class WorkplaceGeofenceService extends IntentService
{
	private String TAG = "HPF";
	private boolean _hasEntered = false;
	private boolean _hasExited = true;
	private Timer _reminderTimer = null;

	/**
	 * @param name
	 */
	public WorkplaceGeofenceService(String name)
	{
		super(name);
	}

	/**
	 * 
	 */
	public WorkplaceGeofenceService()
	{
		this("WorkplaceGeofenceService");
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see android.app.IntentService#onHandleIntent(android.content.Intent)
	 */
	@Override
	protected void onHandleIntent(Intent intent)
	{
		GeofencingEvent geofencingEvent = GeofencingEvent.fromIntent(intent);
		if (geofencingEvent.hasError())
		{
			Log.e(TAG, "Geofence error: " + geofencingEvent.getErrorCode());
		}
		else
		{
			// Get the transition type.
			int geofenceTransition = geofencingEvent.getGeofenceTransition();

			// Test that the reported transition was of interest.
			if (geofenceTransition == Geofence.GEOFENCE_TRANSITION_ENTER)
			{
				_hasEntered = true;
				_hasExited = false;

				startTimer();
			}
			else if (geofenceTransition == Geofence.GEOFENCE_TRANSITION_EXIT)
			{
				_hasEntered = false;
				_hasExited = true;
				if (_reminderTimer != null)
					_reminderTimer.cancel();
			}
			else
			{
				// Log the error.
				Log.e(TAG, "Geofence error, transition: " + geofenceTransition);
			}
		}
	}

	private void startTimer()
	{
		startTimer(3600000);
	}

	/**
	 * Schedule a reminder to walk for 1 hour
	 */
	private void startTimer(int milliseconds)
	{
		_reminderTimer = new Timer();
		_reminderTimer.schedule(new TimerTask()
		{
			@Override
			public void run()
			{
				if (!_hasExited && Utils.getUserId(getApplicationContext()) > 0)
				{
					int whenToShow = checkWhenToShowNotification();
					if (whenToShow == 0)
					{
						sendNotification("You've been at work for a while. Why don't you stretch your legs?");
						startTimer();
					}
					else
					{
						startTimer(whenToShow);
					}
				}
			}
		}, milliseconds);
	}

	private int checkWhenToShowNotification()
	{
		// 0 = now
		int shouldShow = 0;
		String updateDate = SQLHelper.getInstance(getApplicationContext()).getMostRecentStepsUpdate(Utils.getUserId(getApplicationContext()), Utils.getFormattedDateToday());
		if (updateDate != null)
		{
			String timeNow = Utils.getFormattedDateTimeNow();
			// get diff

			SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd kk:mm:ss");
			try
			{
				Date oldDate = format.parse(updateDate);
				Date newDate = format.parse(timeNow);
				
				// if it's been at least an hour, show immediately (return 0)
				// if less than an hour, start timer again for the remaining time til it's been an hour
				int diff = (int) (newDate.getTime() - oldDate.getTime());
				if (diff < 3600000)
				{
					shouldShow = 3600000 - diff;
				}
			}
			catch (ParseException e)
			{
				e.printStackTrace();
			}
		}

		return shouldShow;
	}

	/**
	 * Posts a notification in the notification bar when a transition is detected. If the user clicks
	 * the notification, control goes to the MainActivity.
	 */
	private void sendNotification(String notificationDetails)
	{
		// Create an explicit content Intent that starts the main Activity.
		Intent notificationIntent = new Intent(getApplicationContext(), HomeActivity.class);

		// Construct a task stack.
		TaskStackBuilder stackBuilder = TaskStackBuilder.create(this);

		// Add the main Activity to the task stack as the parent.
		stackBuilder.addParentStack(HomeActivity.class);

		// Push the content Intent onto the stack.
		stackBuilder.addNextIntent(notificationIntent);

		// Get a PendingIntent containing the entire back stack.
		PendingIntent notificationPendingIntent = stackBuilder.getPendingIntent(0, PendingIntent.FLAG_UPDATE_CURRENT);

		// Get a notification builder that's compatible with platform versions >= 4
		Notification.Builder builder = new Notification.Builder(this);

		// Define the notification settings.
		builder
				.setSmallIcon(R.drawable.ic_launcher)
				// In a real app, you may want to use a library like Volley
				// to decode the Bitmap.
				.setLargeIcon(BitmapFactory.decodeResource(getResources(), R.drawable.ic_launcher)).setContentTitle("Time to take a stroll!").setContentText(notificationDetails)
				.setContentIntent(notificationPendingIntent);

		// Dismiss notification once the user touches it.
		builder.setAutoCancel(true);

		// Get an instance of the Notification manager
		NotificationManager mNotificationManager = (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);

		// Issue the notification
		mNotificationManager.notify(0, builder.build());
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see android.app.Service#onCreate()
	 */
	@Override
	public void onCreate()
	{
		super.onCreate();
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see android.app.Service#onDestroy()
	 */
	@Override
	public void onDestroy()
	{
		super.onDestroy();
	}

}
