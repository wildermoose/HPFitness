package com.wildermuth.hpfitness.control;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;

import com.wildermuth.hpfitness.model.HPAddress;
import com.wildermuth.hpfitness.model.LeaderboardEntry;

/**
 * @author $Author: jeff $
 * @version $Rev: 1 $
 * 
 */
public class SQLHelper
{
	private Context _context = null;
	private SQLiteDatabase _db = null;
	private static SQLHelper _instance = null;

	public static SQLHelper getInstance(Context context)
	{
		if (_instance == null)
			_instance = new SQLHelper(context);

		return _instance;
	}

	private SQLHelper(Context context)
	{
		_context = context;
		_db = _context.openOrCreateDatabase("hpfitness_db", Context.MODE_PRIVATE, null);
		_db.execSQL("CREATE TABLE IF NOT EXISTS users(user_id INTEGER PRIMARY KEY, username TEXT, password TEXT);");
		_db.execSQL("CREATE TABLE IF NOT EXISTS steps(user_id INTEGER, date TEXT, update_dt TEXT, step_ct INTEGER);");
		_db.execSQL("CREATE TABLE IF NOT EXISTS user_workplaces(user_id INTEGER, address TEXT, latitude DOUBLE, longitude DOUBLE);");
		_db.execSQL("CREATE TABLE IF NOT EXISTS user_info(user_id INTEGER, height_inches INTEGER);");
	}

	/*
	 * Height
	 */
	/**
	 * Stores the height (if there is already a height, this would add a new one)
	 * 
	 * @param userId
	 * @param address
	 * @param latitude
	 * @param longitude
	 */
	public void storeHeight(int userId, int height)
	{
		ContentValues values = new ContentValues();
		values.put("user_id", userId);
		values.put("height_inches", height);
		_db.insert("user_info", null, values);
	}

	/**
	 * Updates the height (assumes that there is a height already entered)
	 * 
	 * @param userId
	 * @param address
	 * @param latitude
	 * @param longitude
	 */
	public void updateHeight(int userId, int height)
	{
		ContentValues values = new ContentValues();
		values.put("height_inches", height);
		_db.update("user_info", values, "user_id=?", new String[] { Integer.toString(userId) });
	}

	/**
	 * Checks whether the user has specified a height
	 * 
	 * @param userId
	 * @return
	 */
	public boolean hasHeight(int userId)
	{
		boolean exists = false;
		Cursor cursor = _db.rawQuery("select * from user_info where user_id=?", new String[] { Integer.toString(userId) });
		cursor.moveToFirst();
		int count = cursor.getCount();
		cursor.close();

		if (count > 0)
		{
			exists = true;
		}
		return exists;
	}

	/**
	 * Gets the height for the user
	 * 
	 * @param userId
	 * @return
	 */
	public int getHeight(int userId)
	{
		int height = 0;
		Cursor cursor = _db.rawQuery("select height_inches from user_info where user_id=?", new String[] { Integer.toString(userId) });
		if (cursor.getCount() > 0)
		{
			cursor.moveToFirst();
			height = cursor.getInt(0);
		}
		cursor.close();

		return height;
	}

	/*
	 * Leaderboard
	 */
	public List<LeaderboardEntry> getAllUserStepsForDate(String date)
	{
		String[] values = new String[1];
		values[0] = date;

		Cursor cursor = _db
				.rawQuery(
						"SELECT steps.user_id, users.username, steps.step_ct, user_info.height_inches FROM steps INNER JOIN users ON steps.user_id = users.user_id INNER JOIN user_info ON steps.user_id = user_info.user_id WHERE date=? ORDER BY steps.user_id",
						values);
		cursor.moveToFirst();

		List<LeaderboardEntry> entries = new ArrayList<LeaderboardEntry>();

		for (int i = 0; i < cursor.getCount(); i++)
		{
			int userId = cursor.getInt(0);
			String username = cursor.getString(1);
			int stepCount = cursor.getInt(2);
			int height = cursor.getInt(3);
			entries.add(new LeaderboardEntry(userId, username, stepCount, height));
			cursor.moveToNext();
		}

		cursor.close();

		return sortEntries(entries);
	}

	public List<LeaderboardEntry> getAllUserStepsForWeek(String weekStartDate)
	{
		String[] values = new String[2];
		values[0] = weekStartDate;
		values[1] = weekStartDate;

		Cursor cursor = _db
				.rawQuery(
						"SELECT steps.user_id, users.username, steps.step_ct, user_info.height_inches FROM steps INNER JOIN users ON steps.user_id = users.user_id INNER JOIN user_info ON steps.user_id = user_info.user_id WHERE date>=date(?,'-6 days') AND date<=? ORDER BY steps.user_id",
						values);
		return doAllUserSelect(cursor);
	}

	public List<LeaderboardEntry> getAllUserStepsForMonth(String date)
	{
		String[] values = new String[2];
		values[0] = date;
		values[1] = date;

		Cursor cursor = _db
				.rawQuery(
						"SELECT steps.user_id, users.username, steps.step_ct, user_info.height_inches FROM steps INNER JOIN users ON steps.user_id = users.user_id INNER JOIN user_info ON steps.user_id = user_info.user_id WHERE date>=date(?, 'start of month') AND date<=date(?, 'start of month', '+1 month', '-1 day') ORDER BY steps.user_id",
						values);
		return doAllUserSelect(cursor);
	}

	public List<LeaderboardEntry> getAllUserStepsAllTime()
	{
		Cursor cursor = _db
				.rawQuery(
						"SELECT steps.user_id, users.username, steps.step_ct, user_info.height_inches FROM steps INNER JOIN users ON steps.user_id = users.user_id INNER JOIN user_info ON steps.user_id = user_info.user_id ORDER BY steps.user_id",
						null);
		return doAllUserSelect(cursor);
	}

	private List<LeaderboardEntry> doAllUserSelect(Cursor cursor)
	{
		cursor.moveToFirst();

		List<LeaderboardEntry> entries = new ArrayList<LeaderboardEntry>();

		for (int i = 0; i < cursor.getCount(); i++)
		{
			int userId = cursor.getInt(0);
			String username = cursor.getString(1);
			int stepCount = cursor.getInt(2);
			int height = cursor.getInt(3);
			if (entries.size() == 0 || entries.get(entries.size() - 1).getUserId() != userId)
			{
				entries.add(new LeaderboardEntry(userId, username, stepCount, height));
			}
			else
			{
				LeaderboardEntry currentEntry = entries.get(entries.size() - 1);
				currentEntry.setStepCount(currentEntry.getStepCount() + stepCount);
			}

			cursor.moveToNext();
		}

		cursor.close();

		return sortEntries(entries);
	}

	private List<LeaderboardEntry> sortEntries(List<LeaderboardEntry> entries)
	{
		Collections.sort(entries, new Comparator<LeaderboardEntry>()
		{
			@Override
			public int compare(LeaderboardEntry lhs, LeaderboardEntry rhs)
			{

				return (int) (rhs.calculateDistance() - lhs.calculateDistance());
			}
		});
		return entries;
	}

	/*
	 * Step count
	 */

	/**
	 * Gets the step count for the given date
	 * 
	 * Works even if there are no steps for the day so far
	 * 
	 * @param userId
	 * @param date
	 * @return
	 */
	public int getStepsForDate(int userId, String date)
	{
		String[] values = new String[2];
		values[0] = Integer.toString(userId);
		values[1] = date;

		Cursor cursor = _db.rawQuery("select step_ct from steps where user_id=? and date=?", values);
		cursor.moveToFirst();

		// if there are no steps, there is no row, so can store a new row
		int stepCount = 0;
		if (cursor.getCount() > 0)
			stepCount = cursor.getInt(0);
		cursor.close();

		return stepCount;
	}
	
	/**
	 * Gets the step count for the given date
	 * 
	 * Works even if there are no steps for the day so far
	 * 
	 * @param userId
	 * @param date
	 * @return
	 */
	public String getMostRecentStepsUpdate(int userId, String date)
	{
		String[] values = new String[2];
		values[0] = Integer.toString(userId);
		values[1] = date;

		Cursor cursor = _db.rawQuery("select update_dt from steps where user_id=? and date=?", values);
		cursor.moveToFirst();

		// if there are no steps, there is no row
		String updateDate = null;
		if (cursor.getCount() > 0)
			updateDate = cursor.getString(0);
		cursor.close();

		return updateDate;
	}

	/**
	 * Stores a new row in the db for the steps so far on this day
	 * 
	 * @param userId
	 * @param stepCount
	 * @param date
	 * @param updateDate
	 */
	public void storeStepCount(int userId, int stepCount, String date, String updateDate)
	{
		// make sure we don't store if there are 0 steps so we don't get multiple logs for the same
		// day
		if (stepCount > 0)
		{
			ContentValues values = new ContentValues();
			values.put("user_id", userId);
			values.put("step_ct", stepCount);
			values.put("date", date);
			values.put("update_dt", updateDate);
			_db.insert("steps", null, values);
		}
	}

	/**
	 * Updates the step count for the day
	 * 
	 * @param userId
	 * @param stepCount
	 * @param date
	 * @param updateDate
	 */
	public void updateStepCount(int userId, int stepCount, String date, String updateDate)
	{
		ContentValues values = new ContentValues();
		values.put("step_ct", stepCount);
		values.put("update_dt", updateDate);

		String[] whereValues = new String[2];
		whereValues[0] = Integer.toString(userId);
		whereValues[1] = date;

		_db.update("steps", values, "user_id=? and date=?", whereValues);
	}

	/*
	 * Workplace
	 */
	/**
	 * Stores the work address (if there is already a work address, this adds a new one)
	 * 
	 * @param userId
	 * @param address
	 * @param latitude
	 * @param longitude
	 */
	public void storeWorkplace(int userId, String address, double latitude, double longitude)
	{
		ContentValues values = new ContentValues();
		values.put("user_id", userId);
		values.put("address", address);
		values.put("latitude", latitude);
		values.put("longitude", longitude);
		_db.insert("user_workplaces", null, values);
	}

	/**
	 * Updates the work place address (assumes that there is a work address already entered)
	 * 
	 * @param userId
	 * @param address
	 * @param latitude
	 * @param longitude
	 */
	public void updateWorkplace(int userId, String address, double latitude, double longitude)
	{
		ContentValues values = new ContentValues();
		values.put("address", address);
		values.put("latitude", latitude);
		values.put("longitude", longitude);
		_db.update("user_workplaces", values, "user_id=?", new String[] { Integer.toString(userId) });
	}

	/**
	 * Checks whether the user has specified a work address
	 * 
	 * @param userId
	 * @return
	 */
	public boolean hasWorkplace(int userId)
	{
		boolean exists = false;
		Cursor cursor = _db.rawQuery("select count(*) from user_workplaces where user_id=?", new String[] { Integer.toString(userId) });
		cursor.moveToFirst();
		int count = cursor.getInt(0);
		cursor.close();

		if (count > 0)
		{
			exists = true;
		}
		return exists;
	}

	/**
	 * Gets the work address for the user
	 * 
	 * @param userId
	 * @return
	 */
	public HPAddress getWorkAddress(int userId)
	{
		HPAddress addressObject = null;
		Cursor cursor = _db.rawQuery("select address, latitude, longitude from user_workplaces where user_id=?", new String[] { Integer.toString(userId) });
		if (cursor.getCount() > 0)
		{
			cursor.moveToFirst();
			String formattedAddress = cursor.getString(0);
			double latitude = cursor.getDouble(1);
			double longitude = cursor.getDouble(2);
			addressObject = new HPAddress(formattedAddress, latitude, longitude);
		}
		cursor.close();

		return addressObject;
	}

	/*
	 * Login/Registration
	 */

	/***
	 * check whether the user exists in the db yet
	 * 
	 * @param username
	 * @return
	 */
	public boolean userExists(String username)
	{
		boolean exists = false;
		Cursor cursor = _db.rawQuery("select count(*) from users where username=?", new String[] { username });
		cursor.moveToFirst();
		int count = cursor.getInt(0);
		cursor.close();

		if (count > 0)
		{
			exists = true;
		}
		return exists;
	}

	/**
	 * Log in
	 * 
	 * @param username
	 * @param encodedPassword
	 *           must be encoded
	 * @return response
	 */
	public LoginResponse login(String username, String encodedPassword)
	{
		//
		int userId = 0;
		int status = 0;
		Cursor cursor = _db.rawQuery("select * from users where username=? and password=?", new String[] { username, encodedPassword });
		cursor.moveToFirst();

		if (cursor.getCount() > 0)
		{
			status = LoginResponse.SUCCESS;
			// get user_id
			userId = cursor.getInt(0);
		}
		else
		{
			status = LoginResponse.ERROR;
		}
		cursor.close();

		return new LoginResponse(status, userId, username);
	}

	/**
	 * Register
	 * 
	 * @param username
	 * @param encodedPassword
	 *           must be encoded
	 * @return Response info
	 */
	public LoginResponse register(String username, String encodedPassword)
	{
		int userId = 0;
		int status = 0;

		ContentValues values = new ContentValues();
		values.put("username", username);
		values.put("password", encodedPassword);
		long response = _db.insert("users", null, values);

		if (response == -1)
		{
			status = LoginResponse.ERROR;
		}
		else
		{
			status = LoginResponse.SUCCESS;
			userId = (int) response;
		}

		return new LoginResponse(status, userId, username);
	}

	/**
	 * Login/Registration response object
	 * 
	 * @author $Author: jeff $
	 * @version $Rev: 1 $
	 * 
	 */
	public class LoginResponse extends Object
	{
		public static final int SUCCESS = 1;
		public static final int INCORRECT_PW = 2;
		public static final int USER_DNE = 3;
		public static final int ERROR = 4;

		private int _status = 0;
		private int _userId = 0;
		private String _username = null;

		public LoginResponse(int status, int userId, String username)
		{
			_status = status;
			_userId = userId;
			_username = username;
		}

		public int getStatus()
		{
			return _status;
		}

		public int getUserId()
		{
			return _userId;
		}

		public String getUsername()
		{
			return _username;
		}
	}
}
