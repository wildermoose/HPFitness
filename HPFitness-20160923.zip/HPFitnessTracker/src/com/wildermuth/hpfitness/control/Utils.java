package com.wildermuth.hpfitness.control;

import java.nio.charset.StandardCharsets;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Locale;
import java.util.TimeZone;

import javax.crypto.Cipher;
import javax.crypto.SecretKey;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;

import android.content.Context;
import android.content.SharedPreferences;
import android.preference.PreferenceManager;
import android.text.format.DateFormat;
import android.util.Base64;

import com.wildermuth.hpfitness.R;

/**
 * @author $Author: jeff $
 * @version $Rev: 1 $
 * 
 */
public class Utils
{
	public static final String USER_ID = "user_id";
	public static final String USER_LOGIN = "user_login";
	public static final String KEY_3 = "v2iXl0bvUEvPkQ";

	public static SharedPreferences getPrefs(Context context)
	{
		return PreferenceManager.getDefaultSharedPreferences(context);
	}

	public static int getUserId(Context context)
	{
		return getPrefs(context).getInt(USER_ID, 0);
	}

	public static String getUsername(Context context)
	{
		return getPrefs(context).getString(USER_LOGIN, null);
	}

	private static String createKey(Context context)
	{
		return context.getString(R.string.key2) + KEY_3 + context.getString(R.string.key1);
	}

	public static String encodeString(String string, Context context)
	{
		String encryptedString = null;
		try
		{
			DESKeySpec keySpec = new DESKeySpec(createKey(context).getBytes("UTF8"));
			SecretKeyFactory keyFactory = SecretKeyFactory.getInstance("DES");
			SecretKey key = keyFactory.generateSecret(keySpec);

			// encode
			byte[] cleartext = string.getBytes("UTF8");
			Cipher cipher = Cipher.getInstance("DES");
			cipher.init(Cipher.ENCRYPT_MODE, key);
			encryptedString = Base64.encodeToString(cipher.doFinal(cleartext), Base64.DEFAULT);
		}
		catch (Exception e)
		{
			e.printStackTrace();
		}

		return encryptedString;
	}

	public static void storeCredentials(Context context, int userId, String username)
	{
		getPrefs(context).edit().putInt(USER_ID, userId).putString(USER_LOGIN, username).apply();
	}

	public static void clearCredentials(Context context)
	{
		getPrefs(context).edit().remove(USER_ID).remove(USER_LOGIN).apply();
	}
	
	public static String getFormattedDateToday()
	{
		return DateFormat.format("yyyy-MM-dd", Calendar.getInstance(TimeZone.getDefault(), Locale.getDefault()).getTime()).toString();
	}

	public static String getFormattedDateTimeNow()
	{
		return DateFormat.format("yyyy-MM-dd kk:mm:ss", Calendar.getInstance(TimeZone.getDefault(), Locale.getDefault()).getTime()).toString();
	}

	public static double convertStepsToDistance(int height, int stepCount)
	{
		double distance = 0.41d * height;
		distance *= stepCount;
		// convert to feet
		distance /= 12d;

		return distance;
	}
}
