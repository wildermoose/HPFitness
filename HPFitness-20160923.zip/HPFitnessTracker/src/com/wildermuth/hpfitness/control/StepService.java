package com.wildermuth.hpfitness.control;

import android.app.Service;
import android.content.Intent;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import android.os.IBinder;
import android.util.Log;

/**
 * This service handles counting and storing steps that the user takes; it also keeps track of
 * whether the user has walked in the last hour and if they are at their workplace and have not
 * walked recently, sends a notification reminding them to walk
 * 
 * @author $Author: jeff $
 * @version $Rev: 1 $
 * 
 */
public class StepService extends Service implements SensorEventListener
{
	private int _steps = 0;
	private String _date = null;
	private String _lastTimeStamp = null;
	private int _initialSteps = 0;
	private static boolean _isRunning = false;
	private int _userId = 0;

	/*
	 * (non-Javadoc)
	 * 
	 * @see android.app.Service#onCreate()
	 */
	@Override
	public void onCreate()
	{
		super.onCreate();

		_date = Utils.getFormattedDateToday();
		// report steps every 5 minutes
		registerSensor();
		_isRunning = true;
	}

	private void registerSensor()
	{
		SensorManager sensorManager = (SensorManager) getSystemService(SENSOR_SERVICE);
		sensorManager.registerListener(this, sensorManager.getDefaultSensor(Sensor.TYPE_STEP_COUNTER), SensorManager.SENSOR_DELAY_NORMAL, 5 * 60000000);
	}

	private void unregisterSensor()
	{
		try
		{
			SensorManager sensorManager = (SensorManager) getSystemService(SENSOR_SERVICE);
			sensorManager.unregisterListener(this);
		}
		catch (Exception e)
		{
			e.printStackTrace();
		}
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see android.app.Service#onDestroy()
	 */
	@Override
	public void onDestroy()
	{
		super.onDestroy();
		unregisterSensor();
		_isRunning = false;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see android.app.Service#onBind(android.content.Intent)
	 */
	@Override
	public IBinder onBind(Intent intent)
	{
		return null;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see android.hardware.SensorEventListener#onSensorChanged(android.hardware.SensorEvent)
	 */
	@Override
	public void onSensorChanged(SensorEvent event)
	{
		int currentUserId = Utils.getUserId(getApplicationContext());
		// more likely to be a valid event if < MAX_VALUE; also make sure the user is logged in
		// (otherwise, don't store)
		if (event.values[0] < Integer.MAX_VALUE && currentUserId > 0)
		{
			int dbLoggedStepsToday = SQLHelper.getInstance(getApplicationContext()).getStepsForDate(currentUserId, _date);
			int newSteps = (int) event.values[0];

			if (_date.equals(Utils.getFormattedDateToday()))
			{
				// if restarted, check if there are already saved steps in the database
				if (_steps == 0)
				{
					_steps = dbLoggedStepsToday;
				}
				// otherwise, if starting with a different user than before, set _initialSteps so it
				// gets subtracted
				else if (_userId != currentUserId)
				{
					_initialSteps = _steps;
				}
			}
			// if continuing from yesterday, subtract yesterdays steps from todays totals
			else
			{
				_initialSteps = _steps;
			}

			// if more total steps in this session, increase the total step count (minus any steps from
			// previous days)
			if (_steps < newSteps)
			{
				_steps = newSteps - _initialSteps;
			}
			// if the new step total is less than the previous total for today, probably a restart, so
			// add on
			else
			{
				// if restarted, just keep adding the new steps
				// but so we don't add extra, track the initial given amount and subtract it from what
				// gets added
				_steps += newSteps - _initialSteps;
				_initialSteps = newSteps;
			}

			_lastTimeStamp = Utils.getFormattedDateTimeNow();
			_date = Utils.getFormattedDateToday();
			_userId = currentUserId;

			if (dbLoggedStepsToday > 0)
			{
				SQLHelper.getInstance(getApplicationContext()).updateStepCount(Utils.getUserId(getApplicationContext()), _steps, _date, _lastTimeStamp);
			}
			else
			{
				SQLHelper.getInstance(getApplicationContext()).storeStepCount(Utils.getUserId(getApplicationContext()), _steps, _date, _lastTimeStamp);
			}
		}
		// if no user id, store that to avoid storing a wrong distance later 
		// (in case the same user logs out and logs back in; this should guard against that)
		else if (currentUserId <= 0)
		{
			_userId = currentUserId;
		}
	}

	public String getLastTimeStamp()
	{
		return _lastTimeStamp;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see android.hardware.SensorEventListener#onAccuracyChanged(android.hardware.Sensor, int)
	 */
	@Override
	public void onAccuracyChanged(Sensor sensor, int accuracy)
	{
		Log.d("HPF", "Accuracy changed: " + sensor.getName() + " " + accuracy);
	}

	public static boolean isRunning()
	{
		return _isRunning;
	}
}
