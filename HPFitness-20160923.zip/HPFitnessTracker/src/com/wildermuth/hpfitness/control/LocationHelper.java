package com.wildermuth.hpfitness.control;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.http.converter.json.GsonHttpMessageConverter;
import org.springframework.web.client.RestTemplate;

import android.app.Activity;
import android.util.Log;

import com.wildermuth.hpfitness.R;
import com.wildermuth.hpfitness.model.HPAddress;

/**
 * @author $Author: jeff $
 * @version $Rev: 1 $
 * 
 */
public class LocationHelper
{
	// key5 comes before key4; together they create the Google Maps API key for this app
	private final String _key5 = "AIzaSyBMpIFbKZtPKw";
	private Activity _activity = null;

	public LocationHelper(Activity activity)
	{
		_activity = activity;
	}

	public void getLocationsForAddress(final String address, final HPLocationCallback callback)
	{
		// run on separate thread to avoid crashes, etc.
		new Thread(new Runnable()
		{
			@Override
			public void run()
			{
				final String url = "https://maps.googleapis.com/maps/api/geocode/json?address={address}&key={key}";
				Map<String, String> args = new HashMap<String, String>();
				args.put("address", address);
				args.put("key", getAPIKey());

				RestTemplate restTemplate = new RestTemplate();
				restTemplate.getMessageConverters().add(new GsonHttpMessageConverter());
				Map<String, Object> response = restTemplate.getForObject(url, HashMap.class, args);
				Log.d("HPF", "get location: " + response);
				
				final List<HPAddress> returnedAddresses = new ArrayList<HPAddress>();
				boolean success = true;

				// need list of addresses to return
				if (response == null || !response.containsKey("results"))
				{
					// deal with failure
					success = false;
				}
				else
				{
					for (Map<String, Object> result : (List<Map<String, Object>>) response.get("results"))
					{
						try
						{
							String formattedAddress = (String) result.get("formatted_address");
							Map<String, Object> geometry = (Map<String, Object>) result.get("geometry");
							Map<String, Object> location = (Map<String, Object>) geometry.get("location");
							double latitude = (Double) location.get("lat");
							double longitude = (Double) location.get("lng");
							HPAddress returnedAddress = new HPAddress(formattedAddress, latitude, longitude);
							returnedAddresses.add(returnedAddress);
						}
						catch (Exception e)
						{
							e.printStackTrace();
						}
					}
					if (returnedAddresses.size() == 0)
						success = false;
				}
				
				final boolean returnSuccess = success;
				_activity.runOnUiThread(new Runnable()
				{
					@Override
					public void run()
					{
						callback.onLocationsReturned(returnSuccess, returnedAddresses);
					}
				});
				
			}
		}).start();

	}

	public CharSequence[] getAddressesAsArray(List<HPAddress> addresses)
	{
		int size = addresses.size();
		// don't show more than 10 options
		if (size > 10)
			size = 10;
		
		String[] returnArray = new String[size];
		for (int i = 0; i < addresses.size(); i++)
		{
			HPAddress address = addresses.get(i);
			returnArray[i] = address.getFormattedAddress();
		}
		return returnArray;
	}
	
	private String getAPIKey()
	{
		return _key5 + _activity.getString(R.string.key4);
	}

	public interface HPLocationCallback
	{
		public void onLocationsReturned(boolean success, List<HPAddress> addresses);
	}

}
