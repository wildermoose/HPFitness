package com.wildermuth.hpfitness.view;

import java.util.Timer;
import java.util.TimerTask;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;

import com.wildermuth.hpfitness.R;
import com.wildermuth.hpfitness.control.Utils;

public class SplashScreenActivity extends Activity
{

	@Override
	protected void onCreate(Bundle savedInstanceState)
	{
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_splashscreen);

		new Timer().schedule(new TimerTask()
		{

			@Override
			public void run()
			{
				if (isLoggedIn()) 
				{
					// go to main screen
					startActivity(new Intent(SplashScreenActivity.this, HomeActivity.class));
					finish();
				}
				else
				{
					// go to register/login screen
					startActivity(new Intent(SplashScreenActivity.this, LoginActivity.class));
					finish();
				}
			}
		}, 2000);
	}

	private boolean isLoggedIn()
	{
		int userId = Utils.getPrefs(this).getInt(Utils.USER_ID, -1);
		boolean loggedIn = false;
		if (userId != -1)
			loggedIn = true;
		return loggedIn;
	}

}
