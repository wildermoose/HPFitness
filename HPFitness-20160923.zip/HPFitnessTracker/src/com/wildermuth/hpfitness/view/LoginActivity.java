package com.wildermuth.hpfitness.view;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.TextView;
import android.widget.Toast;

import com.wildermuth.hpfitness.R;
import com.wildermuth.hpfitness.control.SQLHelper;
import com.wildermuth.hpfitness.control.Utils;
import com.wildermuth.hpfitness.control.SQLHelper.LoginResponse;

/**
 * @author $Author: jeff $
 * @version $Rev: 1 $
 * 
 */
public class LoginActivity extends Activity
{
	private boolean _buttonsEnabled = true;

	/*
	 * (non-Javadoc)
	 * 
	 * @see android.app.Activity#onCreate(android.os.Bundle)
	 */
	@Override
	protected void onCreate(Bundle savedInstanceState)
	{
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_login);

		findViewById(R.id.login_loginbutton).setOnClickListener(new OnClickListener()
		{
			@Override
			public void onClick(View v)
			{
				if (_buttonsEnabled)
				{
					// disable the buttons so we don't get more than one login at a time
					_buttonsEnabled = false;
					String username = ((TextView) findViewById(R.id.login_usernameedittext)).getText().toString();
					String password = ((TextView) findViewById(R.id.login_passwordedittext)).getText().toString();
					login(username, password);
				}
			}
		});

		findViewById(R.id.login_registerbutton).setOnClickListener(new OnClickListener()
		{
			@Override
			public void onClick(View v)
			{
				if (_buttonsEnabled)
				{
					// disable the buttons so we don't get more than one registration at a time
					_buttonsEnabled = false;
					String username = ((TextView) findViewById(R.id.login_usernameedittext)).getText().toString();
					String password = ((TextView) findViewById(R.id.login_passwordedittext)).getText().toString();
					register(username, password);
				}
			}
		});
	}

	private void login(String username, String password)
	{
		Log.d("HPF", "username: " + username);

		String encodedPassword = Utils.encodeString(password, this);
		if (encodedPassword != null)
		{
			SQLHelper helper = SQLHelper.getInstance(getApplicationContext());
			if (helper.userExists(username))
			{
				// if user exists, login
				LoginResponse response = helper.login(username, encodedPassword);
				if (response.getStatus() == LoginResponse.SUCCESS)
				{
					Utils.storeCredentials(this, response.getUserId(), username);
					//  go to next screen and finish
					startActivity(new Intent(this, HomeActivity.class));
					finish();
					//Toast.makeText(this, "Login successful " + response.getUserId(), Toast.LENGTH_SHORT).show();
				}
				else
				{
					new AlertDialog.Builder(this).setTitle("Incorrect password").setMessage("Please type your password again").show();
					_buttonsEnabled = true;
				}
			}
			else
			{
				// if user does not exist, show "what to register?"
				new AlertDialog.Builder(this).setTitle("No user by this name").setMessage("Tap Register to create a new user by this name.").show();
				_buttonsEnabled = true;
			}
		}
	}

	private void register(String username, String password)
	{
		// register
		String encodedPassword = Utils.encodeString(password, this);
		if (encodedPassword != null)
		{
			SQLHelper helper = SQLHelper.getInstance(getApplicationContext());
			if (helper.userExists(username))
			{

				new AlertDialog.Builder(this).setTitle("User already exists").setMessage("Tap Log In to log in with this username.").show();
				_buttonsEnabled = true;

			}
			// if user does not exist, register
			else
			{
				LoginResponse response = helper.register(username, encodedPassword);

				// if successful,
				if (response.getStatus() == LoginResponse.SUCCESS)
				{
					Utils.storeCredentials(this, response.getUserId(), username);
					// go to next screen and finish
					startActivity(new Intent(this, HomeActivity.class));
					finish();
					// Toast.makeText(this, "Registration successful " + response.getUserId(), Toast.LENGTH_SHORT).show();
				}
				else
				{
					new AlertDialog.Builder(this).setTitle("An Error Occurred").setMessage("Please tap Register again.").show();
					_buttonsEnabled = true;
				}
			}
		}
	}

}
