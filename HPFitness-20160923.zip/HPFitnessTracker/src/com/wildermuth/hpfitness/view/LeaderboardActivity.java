package com.wildermuth.hpfitness.view;

import java.util.ArrayList;
import java.util.List;

import android.app.Activity;
import android.content.Context;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.TextView;

import com.wildermuth.hpfitness.R;
import com.wildermuth.hpfitness.control.SQLHelper;
import com.wildermuth.hpfitness.control.Utils;
import com.wildermuth.hpfitness.model.LeaderboardEntry;

/**
 * @author $Author: jeff $
 * @version $Rev: 1 $
 * 
 */
public class LeaderboardActivity extends Activity
{
	private ListView _listView = null;
	private List<LeaderboardEntry> _listToShow = new ArrayList<LeaderboardEntry>(); 
	private LeaderboardAdapter _adapter = null;
	/*
	 * (non-Javadoc)
	 * 
	 * @see android.app.Activity#onCreate(android.os.Bundle)
	 */
	@Override
	protected void onCreate(Bundle savedInstanceState)
	{
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_leaderboard);
		
		_listView = (ListView) findViewById(R.id.leaderboard_listview);
		_adapter = new LeaderboardAdapter(this, 0);
		_listView.setAdapter(_adapter); 
		
		// Set up leaderboard with basic tabs
		final TextView todayTextView = (TextView) findViewById(R.id.leaderboard_todaybutton);
		todayTextView.setTag("today");
		
		final TextView thisWeekTextView = (TextView) findViewById(R.id.leaderboard_thisweekbutton);
		thisWeekTextView.setTag("week");
		
		final TextView thisMonthTextView = (TextView) findViewById(R.id.leaderboard_thismonthbutton);
		thisMonthTextView.setTag("month");
		
		
		OnClickListener tabListener = new OnClickListener()
		{
			@Override
			public void onClick(View v)
			{
				todayTextView.setBackgroundColor(0x00ffffff);
				todayTextView.setTextColor(0xff000000);
				thisWeekTextView.setBackgroundColor(0x00ffffff);
				thisWeekTextView.setTextColor(0xff000000);
				thisMonthTextView.setBackgroundColor(0x00ffffff);
				thisMonthTextView.setTextColor(0xff000000);
				
				v.setBackgroundColor(getResources().getColor(R.color.splashscreen_background));
				((TextView)v).setTextColor(0xffffffff);
				
				if ("today".equals(v.getTag()))
				{
					// today
					updateList(SQLHelper.getInstance(LeaderboardActivity.this).getAllUserStepsForDate(Utils.getFormattedDateToday()));
					
				}
				else if ("week".equals(v.getTag()))
				{
					// this week
					updateList(SQLHelper.getInstance(LeaderboardActivity.this).getAllUserStepsForWeek(Utils.getFormattedDateToday()));
				}
				else if ("month".equals(v.getTag()))
				{
					// this month
					updateList(SQLHelper.getInstance(LeaderboardActivity.this).getAllUserStepsForMonth(Utils.getFormattedDateToday())); 
				}
			}
		};
		
		// select today by default
		todayTextView.setOnClickListener(tabListener);
		tabListener.onClick(todayTextView);
		
		// set up the other tabs
		thisWeekTextView.setOnClickListener(tabListener);
		thisMonthTextView.setOnClickListener(tabListener);
	}
	
	private void updateList(List<LeaderboardEntry> newEntries)
	{
		_listToShow.clear();
		_listToShow.addAll(newEntries);
		
		_adapter.notifyDataSetChanged();
	}
	
	class LeaderboardAdapter extends ArrayAdapter<LeaderboardEntry>
	{

		public LeaderboardAdapter(Context context, int resource)
		{
			super(context, resource);
			// TODO Auto-generated constructor stub 
		}
		
		/* (non-Javadoc)
		 * @see android.widget.ArrayAdapter#getCount()
		 */
		@Override
		public int getCount()
		{
			return _listToShow.size();
		}
		
		/* (non-Javadoc)
		 * @see android.widget.ArrayAdapter#getItem(int)
		 */
		@Override
		public LeaderboardEntry getItem(int position)
		{
			return _listToShow.get(position); 
		}
		
		/* (non-Javadoc)
		 * @see android.widget.ArrayAdapter#getView(int, android.view.View, android.view.ViewGroup)
		 */
		@Override
		public View getView(int position, View convertView, ViewGroup parent)
		{
			if (convertView == null)
			{
				convertView = getLayoutInflater().inflate(R.layout.view_leaderboarditem, null);
			}
			
			LeaderboardEntry entry = getItem(position);
			
			TextView distanceTextView = (TextView) convertView.findViewById(R.id.leaderboarditem_distance);
			int distance = (int) Utils.convertStepsToDistance(entry.getHeight(), entry.getStepCount());
			if (distance == 0)
				distance = entry.getStepCount();
			distanceTextView.setText(Integer.toString(distance)); 
			TextView usernameTextView = (TextView) convertView.findViewById(R.id.leaderboarditem_username);
			usernameTextView.setText(entry.getUsername());
			
			return convertView;
		}
		
	}
}
