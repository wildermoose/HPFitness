package com.wildermuth.hpfitness.view;

import java.util.ArrayList;
import java.util.List;

import android.app.Activity;
import android.app.AlertDialog;
import android.app.PendingIntent;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.hardware.Sensor;
import android.hardware.SensorManager;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.google.android.gms.common.ConnectionResult;
import com.google.android.gms.common.api.GoogleApiClient;
import com.google.android.gms.common.api.GoogleApiClient.ConnectionCallbacks;
import com.google.android.gms.common.api.GoogleApiClient.OnConnectionFailedListener;
import com.google.android.gms.common.api.ResultCallback;
import com.google.android.gms.common.api.Status;
import com.google.android.gms.location.Geofence;
import com.google.android.gms.location.GeofencingRequest;
import com.google.android.gms.location.LocationServices;
import com.wildermuth.hpfitness.R;
import com.wildermuth.hpfitness.control.LocationHelper;
import com.wildermuth.hpfitness.control.LocationHelper.HPLocationCallback;
import com.wildermuth.hpfitness.control.SQLHelper;
import com.wildermuth.hpfitness.control.Utils;
import com.wildermuth.hpfitness.control.WorkplaceGeofenceService;
import com.wildermuth.hpfitness.model.HPAddress;

/**
 * @author $Author: jeff $
 * @version $Rev: 1 $
 * 
 */
public class HomeActivity extends Activity implements HPLocationCallback, ConnectionCallbacks, OnConnectionFailedListener, ResultCallback<Status>
{
	private LinearLayout _scrollLinearLayout = null;
	private String _savedAddress = null;
	private LocationHelper _lHelper = null;
	private GoogleApiClient _googleApiClient = null;
	private List<Geofence> _geofenceList = null;
	private PendingIntent _geofencePendingIntent = null;
	private boolean _testStepsVisible = false;

	/*
	 * (non-Javadoc)
	 * 
	 * @see android.app.Activity#onCreate(android.os.Bundle)
	 */
	@Override
	protected void onCreate(Bundle savedInstanceState)
	{
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_home);

		_lHelper = new LocationHelper(this);

		_scrollLinearLayout = (LinearLayout) findViewById(R.id.home_scrolllinearlayout);

		SensorManager sensorManager = (SensorManager) getSystemService(Context.SENSOR_SERVICE);
		Sensor countSensor = sensorManager.getDefaultSensor(Sensor.TYPE_STEP_COUNTER);
		if (countSensor == null)
		{
			_testStepsVisible = true;
		}
		
		requestGoogleApis();
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see android.app.Activity#onStart()
	 */
	@Override
	protected void onStart()
	{
		super.onStart();

		_googleApiClient.connect();
		refreshCards();
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see android.app.Activity#onStop()
	 */
	@Override
	protected void onStop()
	{
		super.onStop();
		if (_googleApiClient != null && _googleApiClient.isConnected())
			_googleApiClient.disconnect();

	}

	private void refreshCards()
	{
		// in case coming from Settings (could have entered work on Settings screen), reset all cards
		_scrollLinearLayout.removeAllViews();

		SQLHelper helper = SQLHelper.getInstance(this);
		if (!helper.hasWorkplace(Utils.getUserId(this)))
		{
			showWorkplaceCard();
		}

		if (helper.hasHeight(Utils.getUserId(this)))
		{
			showStepCountCard();

			showMilestoneCard();
		}
		else
		{
			showSetHeightCard();
		}

		
		if (_testStepsVisible)
		{
			// no step count sensor, so show the test card
			showStepCountTestCard();
		}
	}

	private View inflateCard()
	{
		LayoutInflater inflater = getLayoutInflater();
		final View card = inflater.inflate(R.layout.view_card, _scrollLinearLayout, false);
		card.findViewById(R.id.card_closebutton).setOnClickListener(new OnClickListener()
		{
			@Override
			public void onClick(View v)
			{
				_scrollLinearLayout.removeView(card);
			}
		});

		return card;
	}

	private void showStepCountCard()
	{
		final View card = inflateCard();
		// use the tag to dismiss this when the user inputs a workplace
		card.setTag("steps_real");
		((TextView) card.findViewById(R.id.card_titletextview)).setText("Your Stats for Today");

		SQLHelper sHelper = SQLHelper.getInstance(this);

		String date = Utils.getFormattedDateToday();
		int initialSteps = sHelper.getStepsForDate(Utils.getUserId(this), date);
		int initialDistance = (int) Utils.convertStepsToDistance(sHelper.getHeight(Utils.getUserId(this)), initialSteps);
		String yourSteps = "You've walked ";

		yourSteps += initialDistance + (initialDistance == 1 ? " foot so far today." : " feet so far today.");
		if (initialDistance > 0)
			yourSteps += " Nice job!";

		((TextView) card.findViewById(R.id.card_messagetextview)).setText(yourSteps);

		card.findViewById(R.id.card_closebutton).setVisibility(View.INVISIBLE);
		_scrollLinearLayout.addView(card);
	}

	private void showMilestoneCard()
	{
		final View card = inflateCard();
		// use the tag to dismiss this when the user inputs a workplace
		card.setTag("milestone");

		SQLHelper sHelper = SQLHelper.getInstance(this);

		String date = Utils.getFormattedDateToday();
		int initialSteps = sHelper.getStepsForDate(Utils.getUserId(this), date);

		int initialDistance = (int) Utils.convertStepsToDistance(sHelper.getHeight(Utils.getUserId(this)), initialSteps);

		int milestone = initialDistance / 1000;
		milestone += 1;
		milestone *= 1000;
		String title = "Next Milestone: " + milestone;
		((TextView) card.findViewById(R.id.card_titletextview)).setText(title);

		String message = "You're only " + (milestone - initialDistance) + " feet away from the next milestone. Go get 'em!";
		((TextView) card.findViewById(R.id.card_messagetextview)).setText(message);

		card.findViewById(R.id.card_closebutton).setVisibility(View.INVISIBLE);
		_scrollLinearLayout.addView(card);
	}

	/**
	 * My test device is old, so I don't have the ability to test this; I created this to make sure
	 * that everything around the step detection works at least
	 */
	private void showStepCountTestCard()
	{
		final View card = inflateCard();
		// use the tag to dismiss this when the user inputs a workplace
		card.setTag("steps");
		((TextView) card.findViewById(R.id.card_titletextview)).setText("Input Steps");

		String yourSteps = "Looks like you don't have a step count sensor. Just so you can test how the app works otherwise, tap here to input how many steps you've walked. Your steps today: ";
		String date = Utils.getFormattedDateToday();
		Log.d("HPF", "Date from Utils: " + date);
		String time = Utils.getFormattedDateTimeNow();
		Log.d("HPF", "Time from Utils: " + time);

		int initialSteps = SQLHelper.getInstance(this).getStepsForDate(Utils.getUserId(this), date);
		yourSteps += initialSteps + ". Tap to update";
		((TextView) card.findViewById(R.id.card_messagetextview)).setText(yourSteps);
		card.setOnClickListener(new OnClickListener()
		{
			@Override
			public void onClick(View v)
			{
				// create the onclick listener
				DialogInterface.OnClickListener listener = new DialogInterface.OnClickListener()
				{
					@Override
					public void onClick(DialogInterface dialog, int which)
					{
						if (which == DialogInterface.BUTTON_POSITIVE)
						{
							EditText updatedStepsEditText = (EditText) ((AlertDialog) dialog).findViewById(R.id.workplace_line1);

							int updatedSteps = Integer.parseInt(updatedStepsEditText.getText().toString());

							SQLHelper helper = SQLHelper.getInstance(HomeActivity.this);
							int initialSteps = helper.getStepsForDate(Utils.getUserId(HomeActivity.this), Utils.getFormattedDateToday());
							if (initialSteps == 0)
								helper.storeStepCount(Utils.getUserId(HomeActivity.this), updatedSteps, Utils.getFormattedDateToday(), Utils.getFormattedDateTimeNow());
							else
								helper.updateStepCount(Utils.getUserId(HomeActivity.this), initialSteps + updatedSteps, Utils.getFormattedDateToday(), Utils.getFormattedDateTimeNow());

							refreshCards();
							
						//	Log.d("HPF", "updated steps: " + updatedSteps);
						//	Log.d("HPF", "initial steps: " + initialSteps);

						}
					}
				};

				// show enter workplace dialogue
				View workplaceDialogView = getLayoutInflater().inflate(R.layout.dialog_workplace, null);

				((EditText) workplaceDialogView.findViewById(R.id.workplace_line1)).setHint("new steps");

				new AlertDialog.Builder(HomeActivity.this).setView(workplaceDialogView).setPositiveButton("Submit", listener).setNegativeButton("Cancel", listener).show();
			}
		});
		_scrollLinearLayout.addView(card);
	}

	private void showSetHeightCard()
	{
		View card = inflateCard();
		// use the tag to dismiss this when the user inputs a workplace
		card.setTag("height");
		((TextView) card.findViewById(R.id.card_titletextview)).setText("Set your height");
		((TextView) card.findViewById(R.id.card_messagetextview))
				.setText("You haven't set your height yet! If you set it, we'll do cool things like figure out how far you've walked.\nProtip: This makes for WAY better pep talks.");
		card.setOnClickListener(new OnClickListener()
		{
			@Override
			public void onClick(View v)
			{
				// create the onclick listener
				DialogInterface.OnClickListener listener = new DialogInterface.OnClickListener()
				{
					@Override
					public void onClick(DialogInterface dialog, int which)
					{
						if (which == DialogInterface.BUTTON_POSITIVE)
						{
							EditText feet = (EditText) ((AlertDialog) dialog).findViewById(R.id.height_feet);
							EditText inches = (EditText) ((AlertDialog) dialog).findViewById(R.id.height_inches);
							int totalInches = 0;

							try
							{
								totalInches = Integer.parseInt(feet.getText().toString()) * 12;
								totalInches += Integer.parseInt(inches.getText().toString());

								if (totalInches > 0)
								{
									SQLHelper helper = SQLHelper.getInstance(HomeActivity.this);
									helper.storeHeight(Utils.getUserId(HomeActivity.this), totalInches);

									refreshCards();
								}
							}
							catch (NumberFormatException e)
							{
								new AlertDialog.Builder(HomeActivity.this).setTitle("Invalid number").setMessage("Please enter a valid height.").setPositiveButton("OK", null).show();
							}
						}
					}
				};

				// show enter workplace dialogue
				View workplaceDialogView = getLayoutInflater().inflate(R.layout.dialog_height, null);

				new AlertDialog.Builder(HomeActivity.this).setTitle("Set Your Height").setView(workplaceDialogView).setPositiveButton("Submit", listener).setNegativeButton("Cancel", listener).show();
			}
		});
		_scrollLinearLayout.addView(card);
	}

	private void showWorkplaceCard()
	{
		View card = inflateCard();
		// use the tag to dismiss this when the user inputs a workplace
		card.setTag("work");
		((TextView) card.findViewById(R.id.card_titletextview)).setText("Set a Workplace");
		((TextView) card.findViewById(R.id.card_messagetextview)).setText("You don't have a workplace set. If you set one, we'll remind you to walk around every once in a while.");
		card.setOnClickListener(new OnClickListener()
		{
			@Override
			public void onClick(View v)
			{
				// create the onclick listener
				DialogInterface.OnClickListener listener = new DialogInterface.OnClickListener()
				{
					@Override
					public void onClick(DialogInterface dialog, int which)
					{
						if (which == DialogInterface.BUTTON_POSITIVE)
						{
							EditText workplace1 = (EditText) ((AlertDialog) dialog).findViewById(R.id.workplace_line1);
							_savedAddress = workplace1.getText().toString();

							// check address and store
							searchForLocation(_savedAddress);
						}
					}
				};

				// show enter workplace dialogue
				View workplaceDialogView = getLayoutInflater().inflate(R.layout.dialog_workplace, null);
				if (_savedAddress != null)
					((TextView) workplaceDialogView.findViewById(R.id.workplace_line1)).setText(_savedAddress);

				new AlertDialog.Builder(HomeActivity.this).setTitle("Set Your Work Address").setView(workplaceDialogView).setPositiveButton("Submit", listener).setNegativeButton("Cancel", listener)
						.show();
			}
		});
		_scrollLinearLayout.addView(card);
	}

	private void searchForLocation(final String address)
	{
		_lHelper.getLocationsForAddress(address, this);
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see android.app.Activity#onCreateOptionsMenu(android.view.Menu)
	 */
	@Override
	public boolean onCreateOptionsMenu(Menu menu)
	{
		MenuInflater inflater = getMenuInflater();
		inflater.inflate(R.menu.home, menu);
		return true;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see android.app.Activity#onOptionsItemSelected(android.view.MenuItem)
	 */
	@Override
	public boolean onOptionsItemSelected(MenuItem item)
	{
		boolean returnValue = true;
		switch (item.getItemId())
		{
			case R.id.home_menu_refresh:
				refreshCards();
				break;
			case R.id.home_menu_share:
				// share on a multitude of platforms (including Twitter)
				SQLHelper sHelper = SQLHelper.getInstance(this);

				String date = Utils.getFormattedDateToday();
				int initialSteps = sHelper.getStepsForDate(Utils.getUserId(this), date);
				int initialDistance = (int) Utils.convertStepsToDistance(sHelper.getHeight(Utils.getUserId(this)), initialSteps);
				String yourSteps = Utils.getUsername(this) + " has walked ";

				yourSteps += initialDistance + (initialDistance == 1 ? " foot so far today!" : " feet so far today!");
				
				Intent sendIntent = new Intent();
				sendIntent.setAction(Intent.ACTION_SEND);
				sendIntent.putExtra(Intent.EXTRA_TEXT, yourSteps);
				sendIntent.setType("text/plain");
				startActivity(sendIntent);
				break;
			case R.id.home_menu_leaderboard:
				startActivity(new Intent(this, LeaderboardActivity.class));
				break;
			case R.id.home_menu_settings:
				startActivity(new Intent(this, SettingsActivity.class));
				break;
			case R.id.home_menu_logout:
				logout();
				returnValue = true;
				break;
			default:
				returnValue = super.onOptionsItemSelected(item);
				break;
		}

		return returnValue;
	}

	private void logout()
	{
		Utils.clearCredentials(this);
		startActivity(new Intent(this, LoginActivity.class));
		if (_googleApiClient != null && _googleApiClient.isConnected())
		{
			// TODO stop getting updates
			removeGeofences();
			_googleApiClient.disconnect();
		}
		finish();
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * com.wildermuth.hpfitness.control.LocationHelper.HPLocationCallback#onLocationsReturned(boolean
	 * , java.util.List)
	 */
	@Override
	public void onLocationsReturned(boolean success, final List<HPAddress> addresses)
	{
		if (success)
		{
			DialogInterface.OnClickListener listener = new DialogInterface.OnClickListener()
			{
				public void onClick(DialogInterface dialog, int index)
				{
					HPAddress selectedAddress = addresses.get(index);
					Log.d("HPF", selectedAddress.getFormattedAddress() + "; latitude: " + selectedAddress.getLatitude() + ", longitude: " + selectedAddress.getLongitude());
					SQLHelper.getInstance(HomeActivity.this).storeWorkplace(Utils.getUserId(HomeActivity.this), selectedAddress.getFormattedAddress(), selectedAddress.getLatitude(),
							selectedAddress.getLongitude());

					refreshCards();

					updateWorkplaceGeofence();
				}
			};

			String title = "Choose an address";
			if (addresses.size() == 1)
				title = "Tap to verify";

			// show list
			new AlertDialog.Builder(this).setTitle(title).setItems(_lHelper.getAddressesAsArray(addresses), listener).show();
		}
		else
		{
			// if failure, show message
			new AlertDialog.Builder(this).setTitle("Error").setMessage("Unable to find the address you searched for. Please try again.").show();
		}
	}

	private void requestGoogleApis()
	{
		// Create an instance of GoogleAPIClient.
		if (_googleApiClient == null)
		{
			_googleApiClient = new GoogleApiClient.Builder(this).addConnectionCallbacks(this).addOnConnectionFailedListener(this).addApi(LocationServices.API).build();
		}
	}

	private GeofencingRequest getGeofencingRequest()
	{
		GeofencingRequest.Builder builder = new GeofencingRequest.Builder();
		builder.setInitialTrigger(GeofencingRequest.INITIAL_TRIGGER_ENTER);
		builder.addGeofences(_geofenceList);
		return builder.build();
	}

	private void addGeofences()
	{
		// add geofences
		LocationServices.GeofencingApi.addGeofences(_googleApiClient, getGeofencingRequest(), getGeofencePendingIntent()).setResultCallback(this);
	}

	private void removeGeofences()
	{
		// remove geofences
		LocationServices.GeofencingApi.removeGeofences(_googleApiClient,
		// This is the same pending intent that was used in addGeofences().
				getGeofencePendingIntent()).setResultCallback(this); // Result processed in onResult().
	}

	private PendingIntent getGeofencePendingIntent()
	{
		// Reuse the PendingIntent if we already have it.
		if (_geofencePendingIntent != null)
		{
			return _geofencePendingIntent;
		}
		Intent intent = new Intent(this, WorkplaceGeofenceService.class);
		// We use FLAG_UPDATE_CURRENT so that we get the same pending intent back when
		// calling addGeofences() and removeGeofences().
		return PendingIntent.getService(this, 0, intent, PendingIntent.FLAG_UPDATE_CURRENT);
	}

	public void updateWorkplaceGeofence()
	{
		removeGeofences();

		int userId = Utils.getUserId(getApplicationContext());

		HPAddress address = SQLHelper.getInstance(getApplicationContext()).getWorkAddress(userId);

		_geofenceList = new ArrayList<Geofence>();
		_geofenceList.add(new Geofence.Builder()
				// Set the request ID of the geofence. This is a string to identify this
				// geofence.
				.setRequestId("workplace")
				// estimate 600 meter diameter for geofence -- should be big enough
				.setCircularRegion(address.getLatitude(), address.getLongitude(), 300).setExpirationDuration(Geofence.NEVER_EXPIRE)
				.setTransitionTypes(Geofence.GEOFENCE_TRANSITION_ENTER | Geofence.GEOFENCE_TRANSITION_EXIT)
				// get a notification when entering the user's workplace; this starts a timer for an
				// hour
				.build());

		addGeofences();
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * com.google.android.gms.common.api.GoogleApiClient.ConnectionCallbacks#onConnected(android.
	 * os.Bundle)
	 */
	@Override
	public void onConnected(Bundle bundle)
	{
		// TODO start the service?
		Log.d("HPF", "onConnected: " + bundle);

		if (SQLHelper.getInstance(this).hasWorkplace(Utils.getUserId(this)))
			updateWorkplaceGeofence();
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * com.google.android.gms.common.api.GoogleApiClient.ConnectionCallbacks#onConnectionSuspended
	 * (int)
	 */
	@Override
	public void onConnectionSuspended(int reason)
	{
		Log.d("HPF", "onConnectionSuspended: " + reason);
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * com.google.android.gms.common.api.GoogleApiClient.OnConnectionFailedListener#onConnectionFailed
	 * (com.google.android.gms.common.ConnectionResult)
	 */
	@Override
	public void onConnectionFailed(ConnectionResult result)
	{
		// TODO probably retry?
		Log.d("HPF", "onConnectionFailed: " + result);
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * com.google.android.gms.common.api.ResultCallback#onResult(com.google.android.gms.common.api
	 * .Result)
	 */
	@Override
	public void onResult(Status status)
	{
		// TODO from addGeofences

	}

}
