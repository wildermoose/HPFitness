package com.wildermuth.hpfitness.view;

import java.util.List;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import com.wildermuth.hpfitness.R;
import com.wildermuth.hpfitness.control.LocationHelper;
import com.wildermuth.hpfitness.control.LocationHelper.HPLocationCallback;
import com.wildermuth.hpfitness.control.SQLHelper;
import com.wildermuth.hpfitness.control.Utils;
import com.wildermuth.hpfitness.model.HPAddress;

/**
 * @author $Author: jeff $
 * @version $Rev: 1 $
 * 
 */
public class SettingsActivity extends Activity implements HPLocationCallback
{
	private LocationHelper _lHelper = null;
	private boolean _buttonsEnabled = true;

	/*
	 * (non-Javadoc)
	 * 
	 * @see android.app.Activity#onCreate(android.os.Bundle)
	 */
	@Override
	protected void onCreate(Bundle savedInstanceState)
	{
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_settings);

		_lHelper = new LocationHelper(this);

		TextView workAddressTextView = (TextView) findViewById(R.id.settings_workaddress);
		Button workEditButton = (Button) findViewById(R.id.settings_workeditbutton);

		if (SQLHelper.getInstance(this).hasWorkplace(Utils.getUserId(this)))
		{
			HPAddress workAddressObject = SQLHelper.getInstance(this).getWorkAddress(Utils.getUserId(this));
			if (workAddressObject == null)
			{
				workEditButton.setText("Select");
				workAddressTextView.setText("None selected.");
			}
			else
				workAddressTextView.setText(workAddressObject.getFormattedAddress());
		}
		else
		{
			workEditButton.setText("Select");
			workAddressTextView.setText("None selected.");
		}
		workEditButton.setOnClickListener(new OnClickListener()
		{
			@Override
			public void onClick(View v)
			{
				if (_buttonsEnabled)
				{
					// create the onclick listener
					DialogInterface.OnClickListener listener = new DialogInterface.OnClickListener()
					{
						@Override
						public void onClick(DialogInterface dialog, int which)
						{
							if (which == DialogInterface.BUTTON_POSITIVE)
							{
								EditText workplace1 = (EditText) ((AlertDialog) dialog).findViewById(R.id.workplace_line1);
								String address = workplace1.getText().toString();

								// check address and store
								searchForLocation(address);
							}
						}
					};

					// show enter workplace dialogue
					View workplaceDialogView = getLayoutInflater().inflate(R.layout.dialog_workplace, null);
					if (SQLHelper.getInstance(SettingsActivity.this).hasWorkplace(Utils.getUserId(SettingsActivity.this)))
					{
						HPAddress workAddress = SQLHelper.getInstance(SettingsActivity.this).getWorkAddress(Utils.getUserId(SettingsActivity.this));
						if (workAddress != null)
							((TextView) workplaceDialogView.findViewById(R.id.workplace_line1)).setText(workAddress.getFormattedAddress());
					}

					// show enter workplace dialogue
					new AlertDialog.Builder(SettingsActivity.this).setView(workplaceDialogView).setPositiveButton("Submit", listener).setNegativeButton("Cancel", listener).show();

					_buttonsEnabled = false;
				}
			}
		});
	}

	private void searchForLocation(final String address)
	{
		LocationHelper _lHelper = new LocationHelper(this);
		_lHelper.getLocationsForAddress(address, this);
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * com.wildermuth.hpfitness.control.LocationHelper.HPLocationCallback#onLocationsReturned(boolean
	 * , java.util.List)
	 */
	@Override
	public void onLocationsReturned(boolean success, final List<HPAddress> addresses)
	{
		_buttonsEnabled = true;
		if (success)
		{
			DialogInterface.OnClickListener listener = new DialogInterface.OnClickListener()
			{
				public void onClick(DialogInterface dialog, int index)
				{
					HPAddress selectedAddress = addresses.get(index);
					Log.d("HPF", selectedAddress.getFormattedAddress() + "; latitude: " + selectedAddress.getLatitude() + ", longitude: " + selectedAddress.getLongitude());

					// if already exists, do update; otherwise, insert
					SQLHelper sHelper = SQLHelper.getInstance(SettingsActivity.this);
					if (sHelper.hasWorkplace(Utils.getUserId(SettingsActivity.this)))
					{
						sHelper.updateWorkplace(Utils.getUserId(SettingsActivity.this), selectedAddress.getFormattedAddress(), selectedAddress.getLatitude(), selectedAddress.getLongitude());
					}
					else
					{
						sHelper.storeWorkplace(Utils.getUserId(SettingsActivity.this), selectedAddress.getFormattedAddress(), selectedAddress.getLatitude(), selectedAddress.getLongitude());

						// button was switched to Select
						((Button) findViewById(R.id.settings_workeditbutton)).setText("Edit");
					}

					((TextView) findViewById(R.id.settings_workaddress)).setText(selectedAddress.getFormattedAddress());
				}
			};

			String title = "Choose an address";
			if (addresses.size() == 1)
				title = "Tap to verify";

			// show list
			new AlertDialog.Builder(this).setTitle(title).setItems(_lHelper.getAddressesAsArray(addresses), listener).show();
		}
		else
		{
			// if failure, show message
			new AlertDialog.Builder(this).setTitle("Error").setMessage("Unable to find the address you searched for. Please try again.").show();
		}

	}
}
