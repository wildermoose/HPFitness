package com.wildermuth.hpfitness;

import com.wildermuth.hpfitness.control.SQLHelper;
import com.wildermuth.hpfitness.control.StepService;

import android.app.Application;
import android.content.Intent;

/**
 * Application object--is maintained for as long as the app is running
 * @author $Author: jeff $
 * @version $Rev: 1 $
 * 
 */
public class HPApplication extends Application
{
	/*
	 * (non-Javadoc)
	 * 
	 * @see android.app.Application#onCreate()
	 */
	@Override
	public void onCreate()
	{
		super.onCreate();

		// init sql database
		SQLHelper.getInstance(getApplicationContext());

		// start step tracker
		if (!StepService.isRunning())
			startService(new Intent(this, StepService.class));
	}
}
